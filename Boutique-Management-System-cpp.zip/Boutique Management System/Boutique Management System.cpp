#include <iostream>
#include <fstream>
#include <string>
using namespace std;

//without array

void display() {
    cout << "\n**********************   Boutique Management System    ***************************\n";
    cout <<" Enter Your Choice Of selection\n";
    cout << "\n1. Add Item\n";
    cout << "2. Edit Item\n";
    cout << "3. Delete Item\n";
    cout << "4. View Items\n";
    cout << "5. Search Item\n";
    cout << "6. Exit\n";
}

void add() 
{
    string itemName;
	string itemCategory;
	double itemPrice; 
	int itemQuantity;
	
	fstream outfile;
	outfile.open("boutiqueeee.txt",ios::app);
	
	if(outfile.is_open())
	{	
        cout << "\n***********************  Enter Item Details  *****************************\n";
        cout << "\nName:";
        cin>>itemName;
        outfile<<"Name: "<<itemName;
    
        cout << "Category: ";
        cin>>itemCategory;
        outfile<<"Category : "<< itemCategory;
    
	    cout << "Price: ";
        cin >> itemPrice;
        outfile<<"Price : ";
    
	    cout << "Quantity: ";
        cin >> itemQuantity;
        outfile<<"Quantity : "<< itemQuantity;
        cout<<endl;

	    cout << "Item added successfully!" << endl;
        outfile<<"Item added successfully!";
	}
	
	outfile.close();
}

void edit() 
{
	string itemName;
	string itemCategory;
	double itemPrice;
	int itemQuantity;
	
	fstream outfile;
	outfile.open("boutiqueeee.txt",ios::app);
	
	if(outfile.is_open())
    {
	    cout << "\n_________Enter new details for the item_________" << endl;
        cout << "\nName: ";
        cin >> itemName;
        outfile << "\nName : " << itemName << endl;

        cout << "Category: ";
        cin >> itemCategory;
        outfile << "Category : " << itemCategory << endl;

        cout << "Price: ";
        cin >> itemPrice;
        outfile << "Price : " << itemPrice << endl;

        cout << "Quantity: ";
        cin >> itemQuantity;
        outfile << "Quantity : " << itemQuantity << endl;
        cout<<endl;
     
        cout << "Item edited successfully!" << endl;
        outfile<< "Item edited successfully!" << endl;
    }
    
    outfile.close();
}

void deleteI() 
{
   	string itemName;
	string itemCategory;
	double itemPrice;
	int itemQuantity;
	
	fstream outfile;
	outfile.open("boutiqueeee.txt",ios::app);
	cout<<endl;
	
	if(outfile.is_open())
	{
    	cout << "Item deleted successfully!" << endl;
    	outfile<< "Item deleted successfully!" << endl;
        itemName = "";
        itemCategory = "";
        itemPrice = 0.0;
        itemQuantity = 0;
    }
    
    outfile.close();
}

void view() 
{
   ifstream outfile;
	outfile.open("boutiqueeee.txt");
	
    if(outfile.is_open())
	{
		string line;
		while(getline(outfile,line))
		{
			cout<<line<<endl;
		}
	}
	
	outfile.close();
}

void search() 
{
 	string itemName;
	string items[100];
	int itemCount;
	
	fstream outfile;
	outfile.open("boutiqueeee.txt",ios::app);
	
	if(outfile.is_open())
	{
        cout << "\nEnter the name of the item to search: ";
        cin >> itemName; 
 
        bool found = false;
        
        for (int i = 0; i < itemCount; i++) 
		{
          if (items[i] == itemName) 
	       {
                cout << "\nItem found at index " << i+1 << ": " << items[i] << endl;
                outfile<< "\nItem found at index " << i << ": " << items[i] << endl;
                found = true;
                break;
           }
        }

        if (!found) 
    	  {
            cout << "Item not found." << endl;
            outfile<<"Item not found." << endl;
          }
    }
    
    outfile.close();
}

int withoutarrays() {
    string itemName;
    string itemCategory;
    double itemPrice;
    int itemQuantity;

    int choice;

    do {
        display();
        cout << "\nEnter your choice (1-6): ";
        cin >> choice;
        switch (choice) {
        case 1:
            add();
            break;
        case 2:
            edit();
            break;
        case 3:
            deleteI();
            break;
        case 4:
            view();
            break;
        case 5:
            search();
            break;
        case 6:
            cout << "\nExiting the program. Goodbye!" << endl;
            break;
        default:
            cout << "\nInvalid choice. Please try again." << endl;
        }

    } while (choice != 6);

    return 0;
}
//with array
void displayM() 
{
    cout << "\n**********************   Boutique Management System    ***************************\n";
    
	cout << "\n1. Add Item\n";
    cout << "2. Edit Item\n";   
    cout << "3. Delete Item\n";
    cout << "4. View Items\n";
    cout << "5. Search Item\n";
    cout << "6. Exit\n";    
}

void addI() 
{
	string itemName; 
	string itemCategory; 
	double itemPrice; 
	int itemQuantity;
	
	fstream outfile;
	outfile.open("boutiqueeee.txt",ios::app);
		
    if(outfile.is_open())
    {
	    cout << "\n***********************  Enter Item Details  *****************************\n";
        cout << "\nName:";
        cin>>itemName;
        outfile<<"Name: "<<itemName;
    
        cout << "Category: ";
        cin>>itemCategory;
        outfile<<"Category : "<< itemCategory;
    
	    cout << "Price: ";
        cin >> itemPrice;
        outfile<<"Price : "<<itemPrice;
    
	    cout << "Quantity: ";
        cin >> itemQuantity;
        outfile<<"Quantity : "<< itemQuantity;
        cout<<endl;

      	cout << "Item added successfully!" << endl;
        outfile<<"Item added successfully!";
    }
    
	outfile.close();
}



void editI() 
{
	string itemName;
	string itemCategory;
	double itemPrice;
	int itemQuantity;
	
	fstream outfile;
	outfile.open("boutiqueeee.txt",ios::app);
	
	if(outfile.is_open())
	{
        cout << "\n_________Enter new details for the item_________" << endl;
        cout << "\nName: ";
        cin >> itemName;
        outfile << "\nName : " << itemName << endl;

        cout << "Category: ";
        cin >> itemCategory;
        outfile << "Category : " << itemCategory << endl;

        cout << "Price: ";
        cin >> itemPrice;
        outfile << "Price : " << itemPrice << endl;

        cout << "Quantity: ";
        cin >> itemQuantity;
        outfile << "Quantity : " << itemQuantity << endl;
        cout<<endl;
     
        cout << "Item edited successfully!" << endl;
        outfile<< "Item edited successfully!" << endl;
    }

    outfile.close();
}

void deleteItem() 
{
	string itemName;
	string itemCategory;
	double itemPrice;
	int itemQuantity;
	
	fstream outfile;
	outfile.open("boutiqueeee.txt",ios::app);
    cout<<endl;
    
	if(outfile.is_open())
	{
	    cout << "Item deleted successfully!" << endl;
	    outfile<< "Item deleted successfully!" << endl;
        itemName = "";
        itemCategory = "";
        itemPrice = 0.0;
        itemQuantity = 0;
   }
    outfile.close();
}

void viewI() 
{
  ifstream outfile;
	outfile.open("boutiquee.txt");
	if(outfile.is_open())
	{
		string line;
		while(getline(outfile,line))
		{
			cout<<line<<endl;
		}
	}
	outfile.close();
}

void searchI() 
{
	string itemName;
	string items[100];
	int itemCount;
	
	fstream outfile;
	outfile.open("boutiqueeee.txt",ios::app);
	
    if(outfile.is_open())
    {
    	cout << "\nEnter the name of the item to search: ";
        cin >> itemName; 
 
        bool found = false;
	    for (int i = 0; i < itemCount; i++) 
		{
            if (items[i] == itemName) 
			{
               cout << "\nItem found at index " << i+1 << ": " << items[i] << endl;
               outfile<< "\nItem found at index " << i << ": " << items[i] << endl;
               found = true;
               break;
            }
        }

        if (!found) 
	      {
            cout << "Item not found." << endl;
            outfile<<"Item not found." << endl;
          }
    }
    
    outfile.close();
}

int witharrays() 
{
    string itemName;
    string itemCategory;
    double itemPrice;
    int itemQuantity;
    int choice;

    const int MAX_ITEMS = 100;
    string items[MAX_ITEMS];
    
    int itemCount = 0;
    do {
    	
        displayM();
        
        cout << "\nEnter your choice (1-6): ";
        cin >> choice;
        
        switch (choice) 
		{
        case 1:
            addI();
            	//addItemArray(itemName, itemCategory, itemPrice, itemQuantity);
            items[itemCount++] = itemName; // Store item names for search
            break;
        case 2:
            editI();
            break;
        case 3:
            deleteItem();
            break;
        case 4:
            viewI();
            break;
        case 5:
            searchI();
            break;
        case 6:
            cout << "\nExiting the program. Goodbye!" << endl;
            break;
        default:
            cout << "\nInvalid choice. Please try again." << endl;
        }

    } while (choice != 6);


    return 0;
}
//with pointers 

struct Item {
    string itemName;
    string itemCategory;
    double itemPrice;
    int itemQuantity;
};

void displayMenu3() {
    cout << "\n**********************   Boutique Management System    ***************************\n";
    cout << "\n1. Add Item\n";
    cout << "2. Edit Item\n";
    cout << "3. Delete Item\n";
    cout << "4. View Items\n";
    cout << "5. Search Item\n";
    cout << "6. Exit\n";
}

void addItem3(Item* item) {
    fstream outfile;
    outfile.open("Boutiqueeee.txt", ios::app);
    cout << "\n***********************  Enter Item Details  *****************************\n";
    cout << "\nName:";
    cin >> item->itemName;
    outfile << "Name: " << item->itemName << endl;

    cout << "Category: ";
    cin >> item->itemCategory;
    outfile << "Category : " << item->itemCategory << endl;

    cout << "Price: ";
    cin >> item->itemPrice;
    outfile << "Price : " << item->itemPrice << endl;

    cout << "Quantity: ";
    cin >> item->itemQuantity;
    outfile << "Quantity : " << item->itemQuantity << endl;
    cout << endl;

    cout << "Item added successfully!" << endl;
    outfile << "Item added successfully!" << endl;
    outfile.close();
}

void editItem3(Item* item) {
    fstream outfile;
    outfile.open("Boutiqueeee.txt", ios::app);
    cout << "\n_________Enter new details for the item_________" << endl;
    cout << "\nName: ";
    cin >> item->itemName;
    outfile << "\nName : " << item->itemName << endl;

    cout << "Category: ";
    cin >> item->itemCategory;
    outfile << "Category : " << item->itemCategory << endl;

    cout << "Price: ";
    cin >> item->itemPrice;
    outfile << "Price : " << item->itemPrice << endl;

    cout << "Quantity: ";
    cin >> item->itemQuantity;
    outfile << "Quantity : " << item->itemQuantity << endl;
    cout << endl;

    cout << "Item edited successfully!" << endl;
    outfile << "Item edited successfully!" << endl;
    outfile.close();
}

void deleteItem3(Item* item) {
    fstream outfile;
    outfile.open("Boutiqueeee.txt", ios::app);
    cout << endl;
    cout << "Item deleted successfully!" << endl;
    outfile << "Item deleted successfully!" << endl;
    item->itemName = "";
    item->itemCategory = "";
    item->itemPrice = 0.0;
    item->itemQuantity = 0;
    outfile.close();
}

void viewItems3(Item* item) {
    fstream outfile;
    outfile.open("Boutiqueeee.txt", ios::app);
    if(outfile.is_open())
	{
		string line;
		while(getline(outfile,line))
		{
			cout<<line<<endl;
		}
	}
	
    outfile.close();
}

void searchItem3(string itemName, string items[], int itemCount) {
    fstream outfile;
    outfile.open("Boutiqueeee.txt", ios::app);
    cout << "\nEnter the name of the item to search: ";
    cin >> itemName;

    bool found = false;
    for (int i = 0; i < itemCount; i++) {
        if (items[i] == itemName) {
            cout << "\nItem found at index " << i + 1 << ": " << items[i] << endl;
            outfile << "\nItem found at index " << i << ": " << items[i] << endl;
            found = true;
            break;
        }
    }

    if (!found) {
        cout << "Item not found." << endl;
        outfile << "Item not found." << endl;
    }
    outfile.close();
}

int withpointers() {
    Item* currentItem = new Item;

    int choice;

    const int MAX_ITEMS = 100;
    string items[MAX_ITEMS];

    int itemCount = 0;
    do {

        displayMenu3();
        cout << "\nEnter your choice (1-6): ";
        cin >> choice;
        switch (choice) {
        case 1:
            addItem3(currentItem);
            items[itemCount++] = currentItem->itemName; // Store item names for search
            break;
        case 2:
            editItem3(currentItem);
            break;
        case 3:
            deleteItem3(currentItem);
            break;
        case 4:
            viewItems3(currentItem);
            break;
        case 5:
            searchItem3(currentItem->itemName, items, itemCount);
            break;
        case 6:
            cout << "\nExiting the program. Goodbye!" << endl;
            break;
        default:
            cout << "\nInvalid choice. Please try again." << endl;
        }

    } while (choice != 6);

    delete currentItem; // Free memory
    return 0;
}
int main(){
	int choice;
	cout<<"***** How would like to run this program ?*****"<<endl;
	cout<<"1 . Without Arrays."<<endl;
	cout<<"2 . With Arrays."<<endl;
	cout<<"3 . With Pointers."<<endl;
	cout<<"4 . Exit."<<endl;
	cin>>choice;
	switch(choice){
		case 1:
			withoutarrays();
			break;
		case 2:
			witharrays();
			break;
		case 3:
			withpointers();
			break;		
		case 4:
		cout<<"Exiting Program Thankyou !"	<<endl;
		break;
		default:
			cout<<"Invalid choice please select between ( 1-4)."<<endl;
	}
	return 0;
}